"use client";
import { useState } from "react";
import { Brain, AlertTriangle, TrendingUp, ChevronDown, ChevronUp } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { mockAIAnalysis } from "@/lib/mock-data";
import { RiskBadge, RiskScoreBar } from "@/components/ui";
import FileUpload from "@/components/ui/FileUpload";
import { cn, getRiskColor } from "@/lib/utils";
import type { AIRiskAnalysis, RiskClause } from "@/types";

function ClauseCard({ clause }: { clause: RiskClause }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className={cn("rounded-xl border p-4 transition-all", getRiskColor(clause.riskLevel))}>
      <button className="w-full flex items-start justify-between gap-3 text-left" onClick={() => setExpanded(!expanded)}>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm font-semibold text-gray-900">{clause.clauseTitle}</span>
            <RiskBadge level={clause.riskLevel} score={clause.riskScore} />
            <span className="text-xs text-gray-400 bg-white/60 px-2 py-0.5 rounded-full border border-gray-200">{clause.category}</span>
          </div>
          <p className="text-xs text-gray-600 mt-1.5 line-clamp-2">{clause.clauseText}</p>
        </div>
        {expanded ? <ChevronUp className="w-4 h-4 text-gray-400 flex-shrink-0 mt-0.5" /> : <ChevronDown className="w-4 h-4 text-gray-400 flex-shrink-0 mt-0.5" />}
      </button>

      {expanded && (
        <div className="mt-4 pt-4 border-t border-current/10 space-y-3 animate-fade-in">
          <div>
            <p className="text-[11px] font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Original Clause</p>
            <p className="text-xs text-gray-700 bg-white/70 p-3 rounded-lg border border-gray-200 italic">"{clause.clauseText}"</p>
          </div>
          <div>
            <p className="text-[11px] font-semibold text-emerald-700 uppercase tracking-wide mb-1.5">✏ Suggested Redline</p>
            <p className="text-xs text-gray-700 bg-emerald-50 p-3 rounded-lg border border-emerald-200">{clause.suggestedRedline}</p>
          </div>
          <div>
            <p className="text-[11px] font-semibold text-gray-500 uppercase tracking-wide mb-1">Risk Score</p>
            <RiskScoreBar score={clause.riskScore} />
          </div>
        </div>
      )}
    </div>
  );
}

export default function AIRiskPage() {
  const [analysis, setAnalysis] = useState<AIRiskAnalysis | null>(null);
  const [showDemo, setShowDemo] = useState(false);

  const analyzeMutation = useMutation({
    mutationFn: api.ai.analyzeContract,
    onSuccess: (data) => setAnalysis(data),
  });

  const handleFile = (file: File) => {
    analyzeMutation.mutate(file);
  };

  const currentAnalysis = analysis ?? (showDemo ? mockAIAnalysis : null);

  const riskCounts = currentAnalysis
    ? {
        critical: currentAnalysis.clauses.filter((c) => c.riskLevel === "critical").length,
        high: currentAnalysis.clauses.filter((c) => c.riskLevel === "high").length,
        medium: currentAnalysis.clauses.filter((c) => c.riskLevel === "medium").length,
        low: currentAnalysis.clauses.filter((c) => c.riskLevel === "low").length,
      }
    : null;

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
            <Brain className="w-5 h-5 text-purple-500" /> AI Risk Analysis
          </h1>
          <p className="text-sm text-gray-500 mt-0.5">Upload a contract PDF to extract clauses and assess risk</p>
        </div>
        <button
          onClick={() => setShowDemo(true)}
          className="text-sm text-purple-600 hover:text-purple-700 font-medium border border-purple-200 bg-purple-50 px-3 py-1.5 rounded-lg hover:bg-purple-100 transition-colors"
        >
          Load Demo Analysis
        </button>
      </div>

      {!currentAnalysis ? (
        <div className="max-w-lg mx-auto mt-8">
          <div className="bg-white rounded-2xl border border-gray-200 p-8">
            <div className="text-center mb-6">
              <div className="w-14 h-14 bg-purple-50 border border-purple-200 rounded-2xl flex items-center justify-center mx-auto mb-3">
                <Brain className="w-7 h-7 text-purple-500" />
              </div>
              <h2 className="text-base font-semibold text-gray-900">Analyze Contract Risk</h2>
              <p className="text-sm text-gray-500 mt-1">AI extracts clauses, scores risk, and suggests redlines</p>
            </div>
            <FileUpload
              accept=".pdf"
              label="Upload contract PDF"
              description="PDF up to 25MB"
              onFileSelect={handleFile}
              uploading={analyzeMutation.isPending}
            />
            {analyzeMutation.isPending && (
              <div className="mt-4 space-y-2">
                {["Extracting text…", "Identifying clauses…", "Scoring risk levels…", "Generating redlines…"].map((step, i) => (
                  <div key={step} className="flex items-center gap-2 text-xs text-gray-500" style={{ animationDelay: `${i * 0.5}s` }}>
                    <div className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-pulse" />
                    {step}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-5 animate-fade-in">
          {/* Score overview */}
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-6">
                <div className="text-center">
                  <div className={cn("text-5xl font-bold",
                    currentAnalysis.overallRiskScore >= 7 ? "text-red-600" :
                    currentAnalysis.overallRiskScore >= 5 ? "text-orange-500" :
                    currentAnalysis.overallRiskScore >= 3 ? "text-amber-500" : "text-emerald-600"
                  )}>
                    {currentAnalysis.overallRiskScore.toFixed(1)}
                  </div>
                  <div className="text-xs text-gray-400 mt-1">/ 10</div>
                  <RiskBadge level={currentAnalysis.overallRiskLevel} />
                </div>
                <div className="space-y-1.5">
                  <p className="text-sm font-semibold text-gray-900">{currentAnalysis.contractName}</p>
                  <p className="text-xs text-gray-500 max-w-md">{currentAnalysis.summary}</p>
                  <p className="text-[11px] text-gray-400">Analyzed: {new Date(currentAnalysis.analyzedAt).toLocaleString()}</p>
                </div>
              </div>
              <div className="flex-shrink-0">
                <button
                  onClick={() => { setAnalysis(null); setShowDemo(false); }}
                  className="text-xs text-gray-500 hover:text-gray-700 border border-gray-200 px-3 py-1.5 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  New Analysis
                </button>
              </div>
            </div>

            {/* Risk breakdown bar */}
            {riskCounts && (
              <div className="mt-5 pt-4 border-t border-gray-100">
                <p className="text-xs font-medium text-gray-500 mb-2.5">Clause Risk Breakdown ({currentAnalysis.clauses.length} clauses)</p>
                <div className="flex gap-3 flex-wrap">
                  {[
                    { label: "Critical", count: riskCounts.critical, color: "bg-red-500" },
                    { label: "High", count: riskCounts.high, color: "bg-orange-400" },
                    { label: "Medium", count: riskCounts.medium, color: "bg-amber-400" },
                    { label: "Low", count: riskCounts.low, color: "bg-emerald-400" },
                  ].map((r) => (
                    <div key={r.label} className="flex items-center gap-1.5 text-xs text-gray-600">
                      <span className={`w-2.5 h-2.5 rounded-sm ${r.color}`} />
                      {r.count} {r.label}
                    </div>
                  ))}
                </div>
                <div className="mt-2 flex rounded-full overflow-hidden h-2">
                  {[
                    { count: riskCounts.critical, color: "bg-red-500" },
                    { count: riskCounts.high, color: "bg-orange-400" },
                    { count: riskCounts.medium, color: "bg-amber-400" },
                    { count: riskCounts.low, color: "bg-emerald-400" },
                  ].map((r, i) => r.count > 0 && (
                    <div key={i} className={r.color} style={{ flex: r.count }} />
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* High-risk alert */}
          {(riskCounts?.critical ?? 0) > 0 && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3">
              <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm font-semibold text-red-800">Critical Risk Detected</p>
                <p className="text-xs text-red-700 mt-0.5">
                  {riskCounts?.critical} critical clause(s) require immediate legal review before this contract can be executed.
                </p>
              </div>
            </div>
          )}

          {/* Clauses */}
          <div>
            <h2 className="text-sm font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-blue-500" />
              Extracted Clauses — click to expand and view redlines
            </h2>
            <div className="space-y-2.5">
              {currentAnalysis.clauses.map((clause) => (
                <ClauseCard key={clause.id} clause={clause} />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
