"use client";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { CheckCircle2, XCircle, Clock, Filter } from "lucide-react";
import Link from "next/link";
import { api } from "@/lib/api";
import { mockContracts, mockApprovalStages } from "@/lib/mock-data";
import { StatusBadge, RiskBadge } from "@/components/ui";
import ApprovalTimeline from "@/components/approvals/ApprovalTimeline";

const STAGE_LABELS = { legal: "Legal", finance: "Finance", compliance: "Compliance", complete: "Complete" };

export default function ApprovalsPage() {
  const [selected, setSelected] = useState(mockContracts[0]);
  const queryClient = useQueryClient();

  const pendingContracts = mockContracts.filter((c) =>
    ["draft","in_review"].includes(c.status)
  );

  const { data: stages = [] } = useQuery({
    queryKey: ["approvals", selected?.contractId],
    queryFn: () => api.contracts.getApprovals(selected?.contractId ?? ""),
    enabled: !!selected,
  });

  const approveMutation = useMutation({
    mutationFn: ({ id, comments }: { id: string; comments: string }) =>
      api.contracts.approve(id, comments),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["approvals"] }),
  });

  const rejectMutation = useMutation({
    mutationFn: ({ id, comments }: { id: string; comments: string }) =>
      api.contracts.reject(id, comments),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["approvals"] }),
  });

  const stats = {
    pending: mockApprovalStages.filter((s) => s.status === "pending").length,
    approved: mockApprovalStages.filter((s) => s.status === "approved").length,
    rejected: mockApprovalStages.filter((s) => s.status === "rejected").length,
  };

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Awaiting Action", count: stats.pending, icon: <Clock className="w-4 h-4" />, color: "text-amber-600 bg-amber-50 border-amber-200" },
          { label: "Approved", count: stats.approved, icon: <CheckCircle2 className="w-4 h-4" />, color: "text-emerald-600 bg-emerald-50 border-emerald-200" },
          { label: "Rejected", count: stats.rejected, icon: <XCircle className="w-4 h-4" />, color: "text-red-600 bg-red-50 border-red-200" },
        ].map((s) => (
          <div key={s.label} className={`flex items-center gap-3 p-4 rounded-xl border bg-white`}>
            <div className={`p-2 rounded-lg border ${s.color}`}>{s.icon}</div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{s.count}</p>
              <p className="text-xs text-gray-500">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Two-panel layout */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        {/* Contract list */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200 overflow-hidden">
          <div className="px-4 py-3.5 border-b border-gray-100 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-gray-900">Pending Contracts</h2>
            <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">{pendingContracts.length}</span>
          </div>
          <div className="divide-y divide-gray-50">
            {pendingContracts.map((c) => (
              <button
                key={c.id}
                onClick={() => setSelected(c)}
                className={`w-full text-left px-4 py-3.5 transition-colors hover:bg-gray-50 ${selected?.id === c.id ? "bg-blue-50 border-r-2 border-[#2563eb]" : ""}`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-xs font-mono font-semibold text-blue-600">{c.contractId}</p>
                    <p className="text-sm font-medium text-gray-800 mt-0.5 truncate">{c.vendor}</p>
                    <p className="text-xs text-gray-400 mt-0.5">{c.client}</p>
                  </div>
                  <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
                    <StatusBadge status={c.status} />
                    <span className="text-[11px] text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded capitalize">{STAGE_LABELS[c.approvalStage]}</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Approval detail */}
        <div className="lg:col-span-3 space-y-4">
          {selected ? (
            <>
              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h2 className="text-base font-semibold text-gray-900">{selected.vendor}</h2>
                    <p className="text-xs text-gray-500 mt-0.5">{selected.contractId} · {selected.client}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <RiskBadge level={selected.riskLevel} score={selected.riskScore} />
                    <Link href={"/contracts/"+selected.id} className="text-xs text-blue-600 hover:underline">View contract →</Link>
                  </div>
                </div>
                <ApprovalTimeline
                  stages={stages}
                  currentStage={selected.approvalStage}
                  onApprove={(id, comments) => approveMutation.mutate({ id, comments })}
                  onReject={(id, comments) => rejectMutation.mutate({ id, comments })}
                />
              </div>

              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <h3 className="text-sm font-semibold text-gray-900 mb-3">Approval History</h3>
                <div className="space-y-2">
                  {stages.filter((s) => s.status !== "pending").map((s) => (
                    <div key={s.id} className="flex items-start gap-3 p-2.5 bg-gray-50 rounded-lg">
                      {s.status === "approved"
                        ? <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />
                        : <XCircle className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />}
                      <div>
                        <p className="text-xs font-medium text-gray-700">{s.approver} · <span className="text-gray-400 capitalize">{s.stage}</span></p>
                        {s.comments && <p className="text-xs text-gray-500 mt-0.5 italic">"{s.comments}"</p>}
                        {s.timestamp && <p className="text-[11px] text-gray-400 mt-0.5">{new Date(s.timestamp).toLocaleString()}</p>}
                      </div>
                    </div>
                  ))}
                  {stages.filter((s) => s.status !== "pending").length === 0 && (
                    <p className="text-xs text-gray-400 italic">No completed stages yet.</p>
                  )}
                </div>
              </div>
            </>
          ) : (
            <div className="bg-white rounded-xl border border-gray-200 flex items-center justify-center h-48">
              <p className="text-sm text-gray-400">Select a contract to view approval workflow</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
