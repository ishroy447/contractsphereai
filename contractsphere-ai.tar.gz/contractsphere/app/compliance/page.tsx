"use client";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Upload, AlertTriangle, CheckCircle2, XCircle, Calendar } from "lucide-react";
import { api } from "@/lib/api";
import { ComplianceStatusBadge } from "@/components/ui";
import FileUpload from "@/components/ui/FileUpload";
import { formatDate } from "@/lib/utils";
import type { ComplianceDocType } from "@/types";

const DOC_TYPES: ComplianceDocType[] = ["W9", "COI", "Insurance", "ACH", "Other"];

export default function CompliancePage() {
  const [uploadType, setUploadType] = useState<ComplianceDocType>("W9");
  const [uploading, setUploading] = useState(false);
  const [uploaded, setUploaded] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>("all");

  const { data: docs = [], isLoading } = useQuery({
    queryKey: ["compliance"],
    queryFn: api.compliance.list,
  });

  const handleFileSelect = async (file: File) => {
    setUploading(true);
    await api.compliance.upload("v1", uploadType, file);
    setUploading(false);
    setUploaded(true);
    setTimeout(() => setUploaded(false), 3000);
  };

  const filtered = docs.filter((d) => filterStatus === "all" || d.status === filterStatus);

  const expiredCount = docs.filter((d) => d.status === "expired").length;
  const expiringSoonCount = docs.filter((d) => d.status === "expiring_soon").length;
  const validCount = docs.filter((d) => d.status === "valid").length;

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Valid Documents", count: validCount, icon: <CheckCircle2 className="w-4 h-4" />, color: "text-emerald-600 bg-emerald-50 border-emerald-200" },
          { label: "Expiring Soon", count: expiringSoonCount, icon: <AlertTriangle className="w-4 h-4" />, color: "text-amber-600 bg-amber-50 border-amber-200" },
          { label: "Expired", count: expiredCount, icon: <XCircle className="w-4 h-4" />, color: "text-red-600 bg-red-50 border-red-200" },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-xl border border-gray-200 p-4 flex items-center gap-3">
            <div className={`p-2 rounded-lg border ${s.color}`}>{s.icon}</div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{s.count}</p>
              <p className="text-xs text-gray-500">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Docs table */}
        <div className="lg:col-span-2 space-y-4">
          {/* Alerts */}
          {(expiredCount > 0 || expiringSoonCount > 0) && (
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-amber-800">Compliance Action Required</p>
                  <p className="text-xs text-amber-700 mt-0.5">
                    {expiredCount > 0 && `${expiredCount} document(s) have expired. `}
                    {expiringSoonCount > 0 && `${expiringSoonCount} document(s) expiring within 30 days.`}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Filter tabs */}
          <div className="flex gap-2">
            {[
              { label: "All", value: "all" },
              { label: "Valid", value: "valid" },
              { label: "Expiring Soon", value: "expiring_soon" },
              { label: "Expired", value: "expired" },
            ].map((f) => (
              <button
                key={f.value}
                onClick={() => setFilterStatus(f.value)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                  filterStatus === f.value ? "bg-[#2563eb] text-white" : "bg-white text-gray-600 border border-gray-200 hover:bg-gray-50"
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200">
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Vendor</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Document</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Type</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Expiry</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Status</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <tr key={i} className="border-b border-gray-50">
                      {Array.from({ length: 5 }).map((_, j) => (
                        <td key={j} className="px-4 py-3"><div className="h-4 bg-gray-100 rounded animate-pulse w-3/4" /></td>
                      ))}
                    </tr>
                  ))
                ) : filtered.map((d) => (
                  <tr key={d.id} className={`border-b border-gray-50 hover:bg-gray-50/50 transition-colors ${d.status === "expired" ? "bg-red-50/30" : d.status === "expiring_soon" ? "bg-amber-50/30" : ""}`}>
                    <td className="px-5 py-3.5 text-sm font-medium text-gray-800">{d.vendor}</td>
                    <td className="px-4 py-3.5 text-xs text-gray-500 font-mono">{d.fileName}</td>
                    <td className="px-4 py-3.5">
                      <span className="px-2 py-0.5 bg-gray-100 text-gray-700 text-xs font-medium rounded border border-gray-200">{d.type}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-gray-400" />
                        <span className="text-xs text-gray-600">{formatDate(d.expiryDate)}</span>
                      </div>
                      <p className={`text-[11px] mt-0.5 ${d.daysUntilExpiry < 0 ? "text-red-500" : d.daysUntilExpiry <= 30 ? "text-amber-600" : "text-gray-400"}`}>
                        {d.daysUntilExpiry < 0 ? `${Math.abs(d.daysUntilExpiry)}d overdue` : `${d.daysUntilExpiry}d remaining`}
                      </p>
                    </td>
                    <td className="px-4 py-3.5"><ComplianceStatusBadge status={d.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Upload panel */}
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h2 className="text-sm font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <Upload className="w-4 h-4 text-blue-500" /> Upload Compliance Doc
            </h2>
            <div className="mb-4">
              <label className="text-xs font-medium text-gray-600 block mb-2">Document Type</label>
              <select
                value={uploadType}
                onChange={(e) => setUploadType(e.target.value as ComplianceDocType)}
                className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400 bg-white"
              >
                {DOC_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <FileUpload
              accept=".pdf,.jpg,.png"
              label="Upload document"
              description="PDF, JPG or PNG up to 10MB"
              onFileSelect={handleFileSelect}
              uploading={uploading}
              uploaded={uploaded}
            />
          </div>

          {/* Required docs checklist */}
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h3 className="text-sm font-semibold text-gray-900 mb-3">Required Documents</h3>
            <div className="space-y-2">
              {DOC_TYPES.filter(t => t !== "Other").map((type) => {
                const hasValid = docs.some((d) => d.type === type && d.status === "valid");
                return (
                  <div key={type} className="flex items-center justify-between py-1.5 border-b border-gray-50 last:border-0">
                    <span className="text-xs text-gray-700 font-medium">{type}</span>
                    <span className={`text-xs font-medium ${hasValid ? "text-emerald-600" : "text-red-500"}`}>
                      {hasValid ? "✓ Valid" : "✗ Missing"}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
