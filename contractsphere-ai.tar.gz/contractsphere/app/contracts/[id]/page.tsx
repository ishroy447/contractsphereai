"use client";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "next/navigation";
import { ArrowLeft, Download, Send, FileText, CheckCircle2, Clock, XCircle } from "lucide-react";
import Link from "next/link";
import { api } from "@/lib/api";
import { StatusBadge, RiskBadge, SignatureBadge, RiskScoreBar } from "@/components/ui";
import { formatCurrency, formatDate } from "@/lib/utils";
import ApprovalTimeline from "@/components/approvals/ApprovalTimeline";

export default function ContractDetailPage() {
  const { id } = useParams<{ id: string }>();

  const { data: contract, isLoading } = useQuery({
    queryKey: ["contract", id],
    queryFn: () => api.contracts.getById(id),
  });
  const { data: approvals = [] } = useQuery({
    queryKey: ["approvals", id],
    queryFn: () => api.contracts.getApprovals(contract?.contractId ?? ""),
    enabled: !!contract,
  });

  if (isLoading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );
  if (!contract) return <div className="text-gray-500 text-sm">Contract not found.</div>;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Back + Header */}
      <div>
        <Link href="/contracts" className="inline-flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-700 mb-4 transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back to contracts
        </Link>
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <h1 className="text-xl font-bold text-gray-900 font-mono">{contract.contractId}</h1>
              <StatusBadge status={contract.status} />
              {contract.signatureStatus && <SignatureBadge status={contract.signatureStatus} />}
            </div>
            <p className="text-sm text-gray-500">{contract.vendor} → {contract.client}</p>
          </div>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-2 px-3 py-2 text-sm border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-gray-700">
              <Download className="w-4 h-4" /> Download DOCX
            </button>
            <button className="flex items-center gap-2 px-3 py-2 text-sm bg-[#2563eb] text-white rounded-lg hover:bg-blue-700 transition-colors">
              <Send className="w-4 h-4" /> Send for Signature
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Left: details */}
        <div className="lg:col-span-2 space-y-5">
          {/* Contract info */}
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h2 className="text-sm font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-500" /> Contract Details
            </h2>
            <div className="grid grid-cols-2 gap-4">
              {[
                { label: "Contract ID", value: contract.contractId, mono: true },
                { label: "Jira Ticket", value: contract.jiraTicketId ?? "—", mono: true },
                { label: "Vendor", value: contract.vendor },
                { label: "Client", value: contract.client },
                { label: "Start Date", value: formatDate(contract.startDate) },
                { label: "End Date", value: formatDate(contract.endDate) },
                { label: "Contract Value", value: formatCurrency(contract.value) },
                { label: "Approval Stage", value: contract.approvalStage },
              ].map(({ label, value, mono }) => (
                <div key={label} className="p-3 bg-gray-50 rounded-lg">
                  <p className="text-[11px] text-gray-400 font-medium uppercase tracking-wide mb-1">{label}</p>
                  <p className={`text-sm text-gray-800 font-medium ${mono ? "font-mono" : ""}`}>{value}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Risk analysis */}
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h2 className="text-sm font-semibold text-gray-900 mb-4">Risk Assessment</h2>
            <div className="flex items-center gap-6 mb-4">
              <div className="text-center">
                <div className={`text-4xl font-bold ${contract.riskScore <= 3 ? "text-emerald-600" : contract.riskScore <= 5 ? "text-amber-600" : contract.riskScore <= 7 ? "text-orange-600" : "text-red-600"}`}>
                  {contract.riskScore.toFixed(1)}
                </div>
                <div className="text-xs text-gray-400 mt-1">Risk Score</div>
              </div>
              <div className="flex-1">
                <RiskBadge level={contract.riskLevel} />
                <div className="mt-3">
                  <RiskScoreBar score={contract.riskScore} />
                </div>
              </div>
            </div>
            <Link href="/ai-risk" className="text-xs text-blue-600 hover:text-blue-700 font-medium">
              Run full AI analysis →
            </Link>
          </div>

          {/* DocuSign status */}
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h2 className="text-sm font-semibold text-gray-900 mb-4">E-Signature Status</h2>
            <div className="flex items-center gap-3">
              {["sent","viewed","signed"].map((step, i) => {
                const statuses = ["sent","viewed","signed","declined"];
                const current = contract.signatureStatus;
                const currentIdx = current ? statuses.indexOf(current) : -1;
                const stepIdx = statuses.indexOf(step);
                const done = currentIdx >= stepIdx && currentIdx >= 0;
                const active = currentIdx === stepIdx;
                return (
                  <div key={step} className="flex items-center gap-2">
                    <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                      done ? "bg-emerald-50 border-emerald-200 text-emerald-700" :
                      active ? "bg-blue-50 border-blue-200 text-blue-700" :
                      "bg-gray-50 border-gray-200 text-gray-400"
                    }`}>
                      {done ? <CheckCircle2 className="w-3.5 h-3.5" /> : active ? <Clock className="w-3.5 h-3.5" /> : <div className="w-3.5 h-3.5 border border-gray-300 rounded-full" />}
                      {step.charAt(0).toUpperCase()+step.slice(1)}
                    </div>
                    {i < 2 && <div className="w-6 h-px bg-gray-200" />}
                  </div>
                );
              })}
              {!contract.signatureStatus && (
                <p className="text-xs text-gray-400 italic">Not yet sent to DocuSign</p>
              )}
            </div>
          </div>
        </div>

        {/* Right: approval timeline */}
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h2 className="text-sm font-semibold text-gray-900 mb-4">Approval Workflow</h2>
            <ApprovalTimeline stages={approvals} currentStage={contract.approvalStage} />
          </div>
        </div>
      </div>
    </div>
  );
}
