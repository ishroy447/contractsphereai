"use client";
import { useQuery } from "@tanstack/react-query";
import { FileText, Clock, AlertTriangle, ShieldAlert, TrendingUp, ArrowRight, Zap } from "lucide-react";
import Link from "next/link";
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { api } from "@/lib/api";
import { mockContracts, contractStatusHistory, riskScoreHistory } from "@/lib/mock-data";
import { MetricCard, StatusBadge, RiskBadge } from "@/components/ui";
import { formatCurrency } from "@/lib/utils";

export default function DashboardPage() {
  const { data: metrics, isLoading } = useQuery({ queryKey: ["metrics"], queryFn: api.dashboard.getMetrics });
  const recentContracts = mockContracts.slice(0, 5);

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard label="Total Contracts" value={isLoading ? "—" : metrics?.totalContracts ?? 0} delta="+8 this month" icon={<FileText className="w-5 h-5" />} color="blue" />
        <MetricCard label="Pending Approvals" value={isLoading ? "—" : metrics?.pendingApprovals ?? 0} delta="Across 3 stages" icon={<Clock className="w-5 h-5" />} color="amber" />
        <MetricCard label="Expiring Docs" value={isLoading ? "—" : metrics?.expiringCompliance ?? 0} delta="Within 30 days" icon={<AlertTriangle className="w-5 h-5" />} color="red" />
        <MetricCard label="High Risk" value={isLoading ? "—" : metrics?.highRiskContracts ?? 0} delta="Needs review" icon={<ShieldAlert className="w-5 h-5" />} color="violet" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h2 className="text-sm font-semibold text-gray-900">Contract Activity</h2>
              <p className="text-xs text-gray-500 mt-0.5">Signed vs pending — last 6 months</p>
            </div>
            <div className="flex items-center gap-4 text-xs text-gray-500">
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block" />Signed</span>
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block" />Pending</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={contractStatusHistory} barGap={4}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ borderRadius: "8px", border: "1px solid #e2e8f0", fontSize: 12 }} cursor={{ fill: "#f8fafc" }} />
              <Bar dataKey="signed" fill="#3b82f6" radius={[3,3,0,0]} />
              <Bar dataKey="pending" fill="#fcd34d" radius={[3,3,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="mb-4">
            <h2 className="text-sm font-semibold text-gray-900">Avg Risk Score</h2>
            <p className="text-xs text-gray-500 mt-0.5">6-month trend</p>
          </div>
          <div className="flex items-baseline gap-1 mb-4">
            <span className="text-3xl font-bold text-gray-900">3.8</span>
            <span className="text-sm text-emerald-600 font-medium flex items-center gap-0.5"><TrendingUp className="w-3.5 h-3.5" />improving</span>
          </div>
          <ResponsiveContainer width="100%" height={140}>
            <AreaChart data={riskScoreHistory}>
              <defs>
                <linearGradient id="riskGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
              <YAxis domain={[0,10]} tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ borderRadius: "8px", border: "1px solid #e2e8f0", fontSize: 12 }} />
              <Area type="monotone" dataKey="score" stroke="#f59e0b" strokeWidth={2} fill="url(#riskGrad)" dot={{ r: 3, fill: "#f59e0b", strokeWidth: 0 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200 overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
            <h2 className="text-sm font-semibold text-gray-900">Recent Contracts</h2>
            <Link href="/contracts" className="text-xs text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1">View all <ArrowRight className="w-3.5 h-3.5" /></Link>
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100">
                <th className="text-left px-5 py-2.5 text-xs font-medium text-gray-500">Contract ID</th>
                <th className="text-left px-4 py-2.5 text-xs font-medium text-gray-500">Vendor</th>
                <th className="text-left px-4 py-2.5 text-xs font-medium text-gray-500">Status</th>
                <th className="text-left px-4 py-2.5 text-xs font-medium text-gray-500">Risk</th>
                <th className="text-left px-4 py-2.5 text-xs font-medium text-gray-500">Value</th>
              </tr>
            </thead>
            <tbody>
              {recentContracts.map((c) => (
                <tr key={c.id} className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors">
                  <td className="px-5 py-3"><Link href={"/contracts/"+c.id} className="font-mono text-xs text-blue-600 hover:underline font-medium">{c.contractId}</Link></td>
                  <td className="px-4 py-3 text-gray-700 text-xs">{c.vendor}</td>
                  <td className="px-4 py-3"><StatusBadge status={c.status} /></td>
                  <td className="px-4 py-3"><RiskBadge level={c.riskLevel} score={c.riskScore} /></td>
                  <td className="px-4 py-3 text-gray-700 text-xs font-medium">{formatCurrency(c.value)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h2 className="text-sm font-semibold text-gray-900 mb-4">Quick Actions</h2>
            <div className="space-y-1.5">
              {[
                { label: "Sync Jira Tickets", href: "/jira", icon: "🔄", desc: "Pull latest C2C tickets" },
                { label: "Run AI Risk Analysis", href: "/ai-risk", icon: "🧠", desc: "Analyze a contract PDF" },
                { label: "Review Approvals", href: "/approvals", icon: "✅", desc: "12 pending decisions" },
                { label: "Check Compliance", href: "/compliance", icon: "🛡️", desc: "7 docs expiring soon" },
              ].map((a) => (
                <Link key={a.href} href={a.href} className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-gray-50 border border-transparent hover:border-gray-200 transition-all group">
                  <span className="text-base">{a.icon}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-gray-800 group-hover:text-blue-600 transition-colors">{a.label}</p>
                    <p className="text-[11px] text-gray-400">{a.desc}</p>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-gray-300 group-hover:text-blue-400 transition-colors" />
                </Link>
              ))}
            </div>
          </div>

          <div className="bg-[#172554] rounded-xl p-5 text-white">
            <div className="flex items-center gap-2 mb-3">
              <Zap className="w-4 h-4 text-blue-300" />
              <p className="text-xs font-semibold text-blue-200 uppercase tracking-wide">Pipeline Health</p>
            </div>
            {[
              { label: "Contracts signed", value: "23", sub: "this month", color: "text-emerald-400" },
              { label: "Avg approval time", value: "2.4d", sub: "per stage", color: "text-blue-300" },
              { label: "Compliance rate", value: "94%", sub: "vendors valid", color: "text-emerald-400" },
            ].map((s) => (
              <div key={s.label} className="flex items-center justify-between py-2 border-b border-blue-800 last:border-0">
                <div>
                  <p className="text-xs text-blue-300">{s.label}</p>
                  <p className="text-[11px] text-blue-500">{s.sub}</p>
                </div>
                <span className={"text-lg font-bold "+s.color}>{s.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
