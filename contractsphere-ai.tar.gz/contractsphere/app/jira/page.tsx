"use client";
import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RefreshCw, FileText, ExternalLink, Search } from "lucide-react";
import { api } from "@/lib/api";
import { formatDate } from "@/lib/utils";

const STATUS_STYLES: Record<string, string> = {
  pending: "bg-gray-100 text-gray-600 border-gray-200",
  validated: "bg-blue-50 text-blue-700 border-blue-200",
  contract_generated: "bg-emerald-50 text-emerald-700 border-emerald-200",
};
const STATUS_LABELS: Record<string, string> = {
  pending: "Pending",
  validated: "Validated",
  contract_generated: "Contract Generated",
};

export default function JiraPage() {
  const [search, setSearch] = useState("");
  const [syncMsg, setSyncMsg] = useState("");

  const { data: tickets = [], isLoading, refetch } = useQuery({
    queryKey: ["jira-tickets"],
    queryFn: api.jira.list,
  });

  const syncMutation = useMutation({
    mutationFn: api.jira.sync,
    onSuccess: (data) => {
      setSyncMsg(`Synced ${data.synced} tickets. ${data.newTickets} new.`);
      refetch();
      setTimeout(() => setSyncMsg(""), 3000);
    },
  });

  const generateMutation = useMutation({
    mutationFn: (ticketId: string) => api.jira.generateContract(ticketId),
    onSuccess: (data) => {
      alert(`Contract ${data.contractId} generated successfully!`);
    },
  });

  const filtered = tickets.filter(
    (t) =>
      search === "" ||
      t.ticketId.toLowerCase().includes(search.toLowerCase()) ||
      t.vendor.toLowerCase().includes(search.toLowerCase()) ||
      t.client.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold text-gray-900">Jira Tickets</h1>
          <p className="text-sm text-gray-500 mt-0.5">C2C vendor onboarding tickets</p>
        </div>
        <button
          onClick={() => syncMutation.mutate()}
          disabled={syncMutation.isPending}
          className="flex items-center gap-2 bg-[#2563eb] text-white text-sm font-medium px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-60"
        >
          <RefreshCw className={`w-4 h-4 ${syncMutation.isPending ? "animate-spin" : ""}`} />
          {syncMutation.isPending ? "Syncing…" : "Sync Jira Tickets"}
        </button>
      </div>

      {syncMsg && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm px-4 py-2.5 rounded-lg animate-fade-in">
          ✓ {syncMsg}
        </div>
      )}

      {/* Integration status */}
      <div className="bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white text-xs font-bold">J</span>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-800">Jira Cloud Connected</p>
              <p className="text-xs text-gray-400">Last synced: 5 minutes ago · Project: C2C-ONBOARDING</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-emerald-600 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-full">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
            Connected
          </div>
        </div>
      </div>

      {/* Filter bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by ticket ID, vendor, or client…"
          className="w-full pl-9 pr-4 py-2.5 text-sm bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400"
        />
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-200">
              <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Ticket ID</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Vendor</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Client</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Start Date</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Rate</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Assignee</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Status</th>
              <th className="text-right px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Actions</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <tr key={i} className="border-b border-gray-50">
                  {Array.from({ length: 8 }).map((_, j) => (
                    <td key={j} className="px-4 py-3"><div className="h-4 bg-gray-100 rounded animate-pulse" style={{ width: "70%" }} /></td>
                  ))}
                </tr>
              ))
            ) : filtered.map((t) => (
              <tr key={t.id} className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors">
                <td className="px-5 py-3.5">
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono text-xs font-semibold text-blue-600">{t.ticketId}</span>
                    <ExternalLink className="w-3 h-3 text-gray-300" />
                  </div>
                </td>
                <td className="px-4 py-3.5 text-sm font-medium text-gray-800">{t.vendor}</td>
                <td className="px-4 py-3.5 text-sm text-gray-600">{t.client}</td>
                <td className="px-4 py-3.5 text-xs text-gray-500">{formatDate(t.startDate)}</td>
                <td className="px-4 py-3.5 text-xs font-mono font-medium text-gray-700">{t.rate}</td>
                <td className="px-4 py-3.5">
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 rounded-full bg-blue-100 flex items-center justify-center">
                      <span className="text-[9px] font-bold text-blue-600">{t.assignee.split(" ").map(n => n[0]).join("")}</span>
                    </div>
                    <span className="text-xs text-gray-600">{t.assignee}</span>
                  </div>
                </td>
                <td className="px-4 py-3.5">
                  <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium border ${STATUS_STYLES[t.status] ?? ""}`}>
                    {STATUS_LABELS[t.status] ?? t.status}
                  </span>
                </td>
                <td className="px-5 py-3.5">
                  <div className="flex items-center justify-end gap-2">
                    {t.status === "validated" && (
                      <button
                        onClick={() => generateMutation.mutate(t.ticketId)}
                        disabled={generateMutation.isPending}
                        className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium bg-[#2563eb] text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-60"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        Generate Contract
                      </button>
                    )}
                    {t.status === "contract_generated" && (
                      <span className="text-xs text-emerald-600 font-medium flex items-center gap-1">
                        ✓ Contract created
                      </span>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
