"use client";
import { useState } from "react";
import { Settings, Zap, Key, Bell, Shield, Users, ChevronRight } from "lucide-react";

const SECTIONS = [
  { id: "integrations", label: "Integrations", icon: Zap },
  { id: "api", label: "API Keys", icon: Key },
  { id: "notifications", label: "Notifications", icon: Bell },
  { id: "security", label: "Security", icon: Shield },
  { id: "team", label: "Team", icon: Users },
];

export default function SettingsPage() {
  const [active, setActive] = useState("integrations");
  const [saved, setSaved] = useState(false);

  const save = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-5 animate-fade-in">
      <h1 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
        <Settings className="w-5 h-5 text-gray-500" /> Settings
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-5">
        {/* Sidebar */}
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden h-fit">
          {SECTIONS.map((s) => {
            const Icon = s.icon;
            return (
              <button
                key={s.id}
                onClick={() => setActive(s.id)}
                className={`w-full flex items-center justify-between px-4 py-3.5 text-sm font-medium transition-colors border-b border-gray-50 last:border-0 ${active === s.id ? "bg-blue-50 text-blue-600 border-r-2 border-[#2563eb]" : "text-gray-700 hover:bg-gray-50"}`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className="w-4 h-4" />
                  {s.label}
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
              </button>
            );
          })}
        </div>

        {/* Content */}
        <div className="lg:col-span-3 space-y-4">
          {active === "integrations" && (
            <div className="space-y-4">
              {[
                { name: "Jira Cloud", desc: "Sync C2C onboarding tickets", connected: true, logo: "J", color: "bg-blue-600" },
                { name: "DocuSign", desc: "E-signature workflow", connected: true, logo: "D", color: "bg-yellow-500" },
                { name: "AWS S3", desc: "Contract document storage", connected: true, logo: "S3", color: "bg-orange-500" },
                { name: "Slack", desc: "Approval notifications", connected: false, logo: "Sl", color: "bg-purple-600" },
                { name: "Salesforce", desc: "CRM contract sync", connected: false, logo: "SF", color: "bg-blue-400" },
              ].map((int) => (
                <div key={int.name} className="bg-white rounded-xl border border-gray-200 p-5 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 ${int.color} rounded-xl flex items-center justify-center flex-shrink-0`}>
                      <span className="text-white text-xs font-bold">{int.logo}</span>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-800">{int.name}</p>
                      <p className="text-xs text-gray-500">{int.desc}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {int.connected
                      ? <span className="text-xs text-emerald-600 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-full flex items-center gap-1"><span className="w-1.5 h-1.5 bg-emerald-500 rounded-full" />Connected</span>
                      : <button className="text-xs text-blue-600 bg-blue-50 border border-blue-200 px-3 py-1.5 rounded-lg hover:bg-blue-100 transition-colors font-medium">Connect</button>}
                  </div>
                </div>
              ))}
            </div>
          )}

          {active === "api" && (
            <div className="bg-white rounded-xl border border-gray-200 p-5 space-y-4">
              <h2 className="text-sm font-semibold text-gray-900">API Configuration</h2>
              {[
                { label: "Jira API Token", value: "••••••••••••••••••••" },
                { label: "DocuSign API Key", value: "••••••••••••••••••••" },
                { label: "OpenAI API Key", value: "••••••••••••••••••••" },
                { label: "AWS Access Key ID", value: "••••••••••••••••••••" },
              ].map((field) => (
                <div key={field.label}>
                  <label className="text-xs font-medium text-gray-600 block mb-1.5">{field.label}</label>
                  <div className="flex gap-2">
                    <input type="password" defaultValue={field.value} className="flex-1 text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400 font-mono" />
                    <button className="px-3 py-2 text-xs border border-gray-200 rounded-lg hover:bg-gray-50 text-gray-600 transition-colors">Reveal</button>
                  </div>
                </div>
              ))}
              <button onClick={save} className={`mt-2 px-4 py-2 text-sm font-medium rounded-lg transition-colors ${saved ? "bg-emerald-600 text-white" : "bg-[#2563eb] text-white hover:bg-blue-700"}`}>
                {saved ? "✓ Saved" : "Save Changes"}
              </button>
            </div>
          )}

          {active === "notifications" && (
            <div className="bg-white rounded-xl border border-gray-200 p-5 space-y-4">
              <h2 className="text-sm font-semibold text-gray-900">Notification Preferences</h2>
              {[
                { label: "Contract approval required", desc: "When a contract needs your approval" },
                { label: "Contract signed", desc: "When all parties have signed" },
                { label: "Compliance expiry (30 days)", desc: "Documents expiring within 30 days" },
                { label: "Compliance expiry (7 days)", desc: "Documents expiring within 7 days" },
                { label: "New Jira ticket", desc: "When a new C2C onboarding ticket is created" },
                { label: "AI risk analysis complete", desc: "When contract risk analysis is ready" },
              ].map((n, i) => (
                <div key={n.label} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                  <div>
                    <p className="text-sm text-gray-800 font-medium">{n.label}</p>
                    <p className="text-xs text-gray-400">{n.desc}</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked={i < 4} />
                    <div className="w-9 h-5 bg-gray-200 rounded-full peer peer-checked:bg-blue-600 peer-checked:after:translate-x-4 after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all" />
                  </label>
                </div>
              ))}
            </div>
          )}

          {(active === "security" || active === "team") && (
            <div className="bg-white rounded-xl border border-gray-200 flex items-center justify-center h-48">
              <p className="text-sm text-gray-400">Coming soon in next release</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
