"use client";
import { useState } from "react";
import { CheckCircle2, XCircle, Clock, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ApprovalStage } from "@/types";

const STAGE_LABELS = { legal: "Legal Review", finance: "Finance Review", compliance: "Compliance Review" };
const STAGE_ORDER: ApprovalStage["stage"][] = ["legal", "finance", "compliance"];

interface Props {
  stages: ApprovalStage[];
  currentStage: string;
  onApprove?: (stageId: string, comments: string) => void;
  onReject?: (stageId: string, comments: string) => void;
}

export default function ApprovalTimeline({ stages, currentStage, onApprove, onReject }: Props) {
  const [comment, setComment] = useState("");
  const [activeStage, setActiveStage] = useState<string | null>(null);

  const getStage = (s: ApprovalStage["stage"]) => stages.find((a) => a.stage === s);

  return (
    <div className="space-y-1">
      {STAGE_ORDER.map((stageName, idx) => {
        const stage = getStage(stageName);
        const isApproved = stage?.status === "approved";
        const isRejected = stage?.status === "rejected";
        const isPending = !stage || stage.status === "pending";
        const isActive = currentStage === stageName && isPending;
        const isExpanded = activeStage === stageName;

        return (
          <div key={stageName}>
            {/* Connector */}
            {idx > 0 && (
              <div className="flex justify-start pl-[19px] py-0.5">
                <div className={cn("w-px h-4", isApproved ? "bg-emerald-300" : "bg-gray-200")} />
              </div>
            )}

            <div className={cn(
              "rounded-lg border transition-all",
              isActive ? "border-blue-200 bg-blue-50/50" :
              isApproved ? "border-emerald-100 bg-emerald-50/30" :
              isRejected ? "border-red-100 bg-red-50/30" :
              "border-gray-100 bg-gray-50/50"
            )}>
              <button
                className="w-full flex items-center gap-3 p-3 text-left"
                onClick={() => setActiveStage(isExpanded ? null : stageName)}
              >
                {/* Status icon */}
                <div className="flex-shrink-0">
                  {isApproved ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                  ) : isRejected ? (
                    <XCircle className="w-5 h-5 text-red-500" />
                  ) : isActive ? (
                    <div className="w-5 h-5 rounded-full border-2 border-blue-400 bg-blue-100 flex items-center justify-center">
                      <div className="w-2 h-2 rounded-full bg-blue-500" />
                    </div>
                  ) : (
                    <Clock className="w-5 h-5 text-gray-300" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <p className={cn("text-xs font-semibold", isApproved ? "text-emerald-700" : isRejected ? "text-red-700" : isActive ? "text-blue-700" : "text-gray-400")}>
                    {STAGE_LABELS[stageName]}
                  </p>
                  {stage?.approver && (
                    <p className="text-[11px] text-gray-400 mt-0.5">{stage.approver} · {stage.approverRole}</p>
                  )}
                  {stage?.timestamp && (
                    <p className="text-[11px] text-gray-400">{new Date(stage.timestamp).toLocaleDateString()}</p>
                  )}
                </div>

                <ChevronDown className={cn("w-3.5 h-3.5 text-gray-400 transition-transform flex-shrink-0", isExpanded && "rotate-180")} />
              </button>

              {/* Expanded: comments + actions */}
              {isExpanded && (
                <div className="px-3 pb-3 pt-0 border-t border-gray-100 mt-0 animate-fade-in">
                  {stage?.comments && (
                    <div className="mb-3 p-2 bg-white rounded border border-gray-100 text-xs text-gray-600 italic">
                      "{stage.comments}"
                    </div>
                  )}

                  {isActive && onApprove && onReject && (
                    <div className="space-y-2 mt-2">
                      <textarea
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        placeholder="Add comments (optional)…"
                        rows={2}
                        className="w-full text-xs border border-gray-200 rounded-lg p-2 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400"
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={() => onApprove(stage?.id ?? "", comment)}
                          className="flex-1 py-1.5 text-xs font-medium bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => onReject(stage?.id ?? "", comment)}
                          className="flex-1 py-1.5 text-xs font-medium bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
                        >
                          Reject
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
