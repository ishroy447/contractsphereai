"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Ticket,
  FileText,
  CheckSquare,
  ShieldCheck,
  Brain,
  Building2,
  Settings,
  ChevronLeft,
  Zap,
  Bell,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAppStore } from "@/store/app-store";

const navItems = [
  { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { label: "Jira Tickets", href: "/jira", icon: Ticket },
  { label: "Contracts", href: "/contracts", icon: FileText },
  { label: "Approvals", href: "/approvals", icon: CheckSquare },
  { label: "Compliance", href: "/compliance", icon: ShieldCheck },
  { label: "AI Risk Analysis", href: "/ai-risk", icon: Brain },
  { label: "Vendor Portal", href: "/vendor", icon: Building2 },
  { label: "Settings", href: "/settings", icon: Settings },
];

export default function Sidebar() {
  const pathname = usePathname();
  const { sidebarCollapsed, toggleSidebar } = useAppStore();

  return (
    <aside
      className={cn(
        "flex flex-col h-screen bg-[#172554] transition-all duration-300 flex-shrink-0",
        sidebarCollapsed ? "w-16" : "w-60"
      )}
    >
      {/* Logo */}
      <div className="flex items-center justify-between px-4 py-5 border-b border-[#1e3a8a]">
        {!sidebarCollapsed && (
          <div className="flex items-center gap-2.5 animate-fade-in">
            <div className="w-8 h-8 bg-[#2563eb] rounded-lg flex items-center justify-center flex-shrink-0">
              <Zap className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="text-white font-semibold text-sm leading-none">ContractSphere</p>
              <p className="text-blue-300 text-[10px] mt-0.5 font-medium tracking-wide">AI PLATFORM</p>
            </div>
          </div>
        )}
        {sidebarCollapsed && (
          <div className="w-8 h-8 bg-[#2563eb] rounded-lg flex items-center justify-center mx-auto">
            <Zap className="w-4 h-4 text-white" />
          </div>
        )}
        {!sidebarCollapsed && (
          <button
            onClick={toggleSidebar}
            className="text-blue-300 hover:text-white transition-colors p-1 rounded"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-4 overflow-y-auto">
        {sidebarCollapsed && (
          <button
            onClick={toggleSidebar}
            className="flex items-center justify-center w-full py-2 mb-2 text-blue-300 hover:text-white"
          >
            <ChevronLeft className="w-4 h-4 rotate-180" />
          </button>
        )}
        <ul className="space-y-0.5 px-2">
          {navItems.map((item) => {
            const isActive = pathname === item.href || pathname.startsWith(item.href + "/");
            const Icon = item.icon;
            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150",
                    isActive
                      ? "bg-[#2563eb] text-white shadow-sm"
                      : "text-blue-200 hover:bg-[#1e3a8a] hover:text-white"
                  )}
                  title={sidebarCollapsed ? item.label : undefined}
                >
                  <Icon className={cn("flex-shrink-0", sidebarCollapsed ? "w-5 h-5 mx-auto" : "w-4 h-4")} />
                  {!sidebarCollapsed && (
                    <span className="truncate">{item.label}</span>
                  )}
                  {!sidebarCollapsed && item.label === "Approvals" && (
                    <span className="ml-auto bg-[#ef4444] text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                      12
                    </span>
                  )}
                  {!sidebarCollapsed && item.label === "Compliance" && (
                    <span className="ml-auto bg-[#f59e0b] text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                      7
                    </span>
                  )}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* User section */}
      {!sidebarCollapsed && (
        <div className="p-3 border-t border-[#1e3a8a]">
          <div className="flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-[#1e3a8a] transition-colors cursor-pointer">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
              <span className="text-white text-xs font-bold">JD</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white text-xs font-medium truncate">Jane Doe</p>
              <p className="text-blue-300 text-[11px] truncate">Contract Manager</p>
            </div>
            <Bell className="w-4 h-4 text-blue-300 flex-shrink-0" />
          </div>
        </div>
      )}
    </aside>
  );
}
