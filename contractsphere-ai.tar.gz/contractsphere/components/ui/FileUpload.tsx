"use client";
import { useState, useCallback } from "react";
import { Upload, File, X, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface FileUploadProps {
  accept?: string;
  label?: string;
  description?: string;
  onFileSelect: (file: File) => void;
  uploading?: boolean;
  uploaded?: boolean;
  className?: string;
}

export default function FileUpload({
  accept = ".pdf,.docx",
  label = "Upload document",
  description = "PDF or DOCX up to 10MB",
  onFileSelect,
  uploading = false,
  uploaded = false,
  className,
}: FileUploadProps) {
  const [dragging, setDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragging(false);
      const file = e.dataTransfer.files[0];
      if (file) {
        setSelectedFile(file);
        onFileSelect(file);
      }
    },
    [onFileSelect]
  );

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      onFileSelect(file);
    }
  };

  return (
    <div className={cn("w-full", className)}>
      <label
        className={cn(
          "relative flex flex-col items-center justify-center w-full border-2 border-dashed rounded-xl py-10 px-6 cursor-pointer transition-all duration-200",
          dragging
            ? "border-blue-400 bg-blue-50"
            : uploaded
            ? "border-emerald-300 bg-emerald-50"
            : uploading
            ? "border-blue-300 bg-blue-50/50"
            : "border-gray-200 bg-gray-50 hover:border-blue-300 hover:bg-blue-50/30"
        )}
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
      >
        <input
          type="file"
          accept={accept}
          className="absolute inset-0 opacity-0 cursor-pointer"
          onChange={handleChange}
          disabled={uploading}
        />

        {uploaded && selectedFile ? (
          <div className="flex flex-col items-center gap-2 animate-fade-in">
            <CheckCircle2 className="w-10 h-10 text-emerald-500" />
            <p className="text-sm font-medium text-emerald-700">{selectedFile.name}</p>
            <p className="text-xs text-emerald-600">Uploaded successfully</p>
          </div>
        ) : uploading ? (
          <div className="flex flex-col items-center gap-3">
            <div className="w-10 h-10 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
            <p className="text-sm text-blue-600 font-medium">Analyzing document…</p>
          </div>
        ) : selectedFile ? (
          <div className="flex flex-col items-center gap-2">
            <File className="w-10 h-10 text-blue-500" />
            <p className="text-sm font-medium text-gray-700">{selectedFile.name}</p>
            <p className="text-xs text-gray-500">{(selectedFile.size / 1024 / 1024).toFixed(2)} MB</p>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-3">
            <div className="w-12 h-12 bg-white border border-gray-200 rounded-xl flex items-center justify-center shadow-sm">
              <Upload className="w-5 h-5 text-gray-400" />
            </div>
            <div className="text-center">
              <p className="text-sm font-medium text-gray-700">{label}</p>
              <p className="text-xs text-gray-400 mt-1">{description}</p>
            </div>
            <span className="text-xs text-blue-600 font-medium bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
              Browse files
            </span>
          </div>
        )}
      </label>
    </div>
  );
}
