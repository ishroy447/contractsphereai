import { cn, getRiskColor, getStatusColor, getSignatureStatusColor, getRiskDot } from "@/lib/utils";
import type { ContractStatus, RiskLevel } from "@/types";

export function StatusBadge({ status }: { status: ContractStatus }) {
  const label = status.replace("_", " ").replace(/\b\w/g, (c) => c.toUpperCase());
  return (
    <span className={cn("inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-xs font-medium border", getStatusColor(status))}>
      {label}
    </span>
  );
}

export function RiskBadge({ level, score }: { level: RiskLevel; score?: number }) {
  return (
    <span className={cn("inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-xs font-medium border", getRiskColor(level))}>
      <span className={cn("w-1.5 h-1.5 rounded-full", getRiskDot(level))} />
      {score !== undefined ? score.toFixed(1) : level.charAt(0).toUpperCase() + level.slice(1)}
    </span>
  );
}

export function SignatureBadge({ status }: { status: string }) {
  const label = status.charAt(0).toUpperCase() + status.slice(1);
  return (
    <span className={cn("inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-xs font-medium border", getSignatureStatusColor(status))}>
      {label}
    </span>
  );
}

export function ApprovalStageBadge({ stage }: { stage: "legal" | "finance" | "compliance" | "complete" }) {
  const colors = {
    legal: "bg-purple-50 text-purple-700 border-purple-200",
    finance: "bg-blue-50 text-blue-700 border-blue-200",
    compliance: "bg-teal-50 text-teal-700 border-teal-200",
    complete: "bg-emerald-50 text-emerald-700 border-emerald-200",
  };
  return (
    <span className={cn("inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium border capitalize", colors[stage])}>
      {stage}
    </span>
  );
}

export function ComplianceStatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    valid: "bg-emerald-50 text-emerald-700 border-emerald-200",
    expiring_soon: "bg-amber-50 text-amber-700 border-amber-200",
    expired: "bg-red-50 text-red-700 border-red-200",
  };
  const labels: Record<string, string> = {
    valid: "Valid",
    expiring_soon: "Expiring Soon",
    expired: "Expired",
  };
  return (
    <span className={cn("inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium border", styles[status] ?? "bg-gray-50 text-gray-600 border-gray-200")}>
      {labels[status] ?? status}
    </span>
  );
}

export function RiskScoreBar({ score }: { score: number }) {
  const pct = (score / 10) * 100;
  const color = score <= 3 ? "bg-emerald-500" : score <= 5 ? "bg-amber-500" : score <= 7 ? "bg-orange-500" : "bg-red-500";
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
        <div className={cn("h-full rounded-full transition-all", color)} style={{ width: `${pct}%` }} />
      </div>
      <span className="text-xs font-medium text-gray-600 w-6 text-right">{score.toFixed(1)}</span>
    </div>
  );
}

export function MetricCard({
  label,
  value,
  delta,
  icon,
  color = "blue",
}: {
  label: string;
  value: string | number;
  delta?: string;
  icon: React.ReactNode;
  color?: "blue" | "emerald" | "amber" | "red" | "violet";
}) {
  const colorMap = {
    blue: "bg-blue-50 text-blue-600",
    emerald: "bg-emerald-50 text-emerald-600",
    amber: "bg-amber-50 text-amber-600",
    red: "bg-red-50 text-red-600",
    violet: "bg-violet-50 text-violet-600",
  };
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-sm transition-shadow">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">{label}</p>
          <p className="text-2xl font-bold text-gray-900 mt-1.5">{value}</p>
          {delta && <p className="text-xs text-gray-500 mt-1">{delta}</p>}
        </div>
        <div className={cn("p-2.5 rounded-lg", colorMap[color])}>
          {icon}
        </div>
      </div>
    </div>
  );
}

export function EmptyState({ message }: { message: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center mb-3">
        <span className="text-2xl">📄</span>
      </div>
      <p className="text-sm text-gray-500">{message}</p>
    </div>
  );
}

export function LoadingRows({ cols = 6, rows = 5 }: { cols?: number; rows?: number }) {
  return (
    <>
      {Array.from({ length: rows }).map((_, i) => (
        <tr key={i} className="border-b border-gray-100">
          {Array.from({ length: cols }).map((_, j) => (
            <td key={j} className="px-4 py-3">
              <div className="h-4 bg-gray-100 rounded animate-pulse" style={{ width: `${60 + Math.random() * 30}%` }} />
            </td>
          ))}
        </tr>
      ))}
    </>
  );
}
