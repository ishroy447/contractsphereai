import {
  mockContracts,
  mockJiraTickets,
  mockComplianceDocs,
  mockApprovalStages,
  mockMetrics,
  mockAIAnalysis,
} from "./mock-data";

const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

export const api = {
  dashboard: {
    getMetrics: async () => {
      await delay(300);
      return mockMetrics;
    },
  },

  contracts: {
    list: async () => {
      await delay(400);
      return mockContracts;
    },
    getById: async (id: string) => {
      await delay(300);
      return mockContracts.find((c) => c.id === id) ?? null;
    },
    getApprovals: async (contractId: string) => {
      await delay(300);
      return mockApprovalStages.filter((a) => a.contractId === contractId);
    },
    approve: async (stageId: string, comments: string) => {
      await delay(600);
      return { success: true, stageId, comments };
    },
    reject: async (stageId: string, comments: string) => {
      await delay(600);
      return { success: true, stageId, comments };
    },
  },

  jira: {
    list: async () => {
      await delay(400);
      return mockJiraTickets;
    },
    sync: async () => {
      await delay(800);
      return { synced: 4, newTickets: 1 };
    },
    generateContract: async (ticketId: string) => {
      await delay(1000);
      return { contractId: `CON-2026-${Math.floor(Math.random() * 9000 + 1000)}`, ticketId };
    },
  },

  compliance: {
    list: async () => {
      await delay(400);
      return mockComplianceDocs;
    },
    upload: async (vendorId: string, type: string, file: File) => {
      await delay(1200);
      return { success: true, documentId: `doc-${Date.now()}`, vendorId, type };
    },
  },

  ai: {
    analyzeContract: async (file: File) => {
      await delay(2000);
      return { ...mockAIAnalysis, contractName: file.name };
    },
    getAnalysis: async (id: string) => {
      await delay(300);
      return mockAIAnalysis;
    },
  },
};

export type ApiClient = typeof api;
