import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import type { RiskLevel, ContractStatus } from "@/types";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(value: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(value);
}

export function formatDate(dateStr: string) {
  return new Date(dateStr).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function getRiskColor(level: RiskLevel) {
  switch (level) {
    case "low": return "text-emerald-600 bg-emerald-50 border-emerald-200";
    case "medium": return "text-amber-600 bg-amber-50 border-amber-200";
    case "high": return "text-orange-600 bg-orange-50 border-orange-200";
    case "critical": return "text-red-600 bg-red-50 border-red-200";
  }
}

export function getRiskDot(level: RiskLevel) {
  switch (level) {
    case "low": return "bg-emerald-500";
    case "medium": return "bg-amber-500";
    case "high": return "bg-orange-500";
    case "critical": return "bg-red-500";
  }
}

export function getStatusColor(status: ContractStatus) {
  switch (status) {
    case "draft": return "text-gray-600 bg-gray-100 border-gray-200";
    case "in_review": return "text-blue-600 bg-blue-50 border-blue-200";
    case "approved": return "text-emerald-600 bg-emerald-50 border-emerald-200";
    case "signed": return "text-violet-600 bg-violet-50 border-violet-200";
    case "rejected": return "text-red-600 bg-red-50 border-red-200";
    case "expired": return "text-gray-500 bg-gray-50 border-gray-200";
  }
}

export function getSignatureStatusColor(status: string) {
  switch (status) {
    case "sent": return "text-blue-600 bg-blue-50 border-blue-200";
    case "viewed": return "text-amber-600 bg-amber-50 border-amber-200";
    case "signed": return "text-emerald-600 bg-emerald-50 border-emerald-200";
    case "declined": return "text-red-600 bg-red-50 border-red-200";
    default: return "text-gray-500 bg-gray-50 border-gray-200";
  }
}

export function getRiskScoreColor(score: number) {
  if (score <= 3) return "text-emerald-600";
  if (score <= 5) return "text-amber-600";
  if (score <= 7) return "text-orange-600";
  return "text-red-600";
}
