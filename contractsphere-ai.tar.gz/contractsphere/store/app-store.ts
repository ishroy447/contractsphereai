import { create } from "zustand";
import type { Contract, AIRiskAnalysis } from "@/types";

interface AppState {
  selectedContract: Contract | null;
  setSelectedContract: (contract: Contract | null) => void;

  sidebarCollapsed: boolean;
  toggleSidebar: () => void;

  activeAnalysis: AIRiskAnalysis | null;
  setActiveAnalysis: (analysis: AIRiskAnalysis | null) => void;

  notifications: Notification[];
  addNotification: (n: Notification) => void;
  clearNotifications: () => void;
}

interface Notification {
  id: string;
  type: "success" | "error" | "warning" | "info";
  message: string;
  timestamp: string;
}

export const useAppStore = create<AppState>((set) => ({
  selectedContract: null,
  setSelectedContract: (contract) => set({ selectedContract: contract }),

  sidebarCollapsed: false,
  toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),

  activeAnalysis: null,
  setActiveAnalysis: (analysis) => set({ activeAnalysis: analysis }),

  notifications: [],
  addNotification: (n) =>
    set((s) => ({ notifications: [n, ...s.notifications].slice(0, 20) })),
  clearNotifications: () => set({ notifications: [] }),
}));
