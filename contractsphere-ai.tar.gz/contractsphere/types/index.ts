export type ContractStatus =
  | "draft"
  | "in_review"
  | "approved"
  | "signed"
  | "rejected"
  | "expired";

export type ApprovalStatus = "pending" | "approved" | "rejected";

export type SignatureStatus = "sent" | "viewed" | "signed" | "declined";

export type RiskLevel = "low" | "medium" | "high" | "critical";

export type ComplianceDocType = "W9" | "COI" | "Insurance" | "ACH" | "Other";

export interface Vendor {
  id: string;
  name: string;
  email: string;
  phone: string;
  type: "C2C" | "W2" | "1099";
  createdAt: string;
}

export interface JiraTicket {
  id: string;
  ticketId: string;
  vendor: string;
  client: string;
  startDate: string;
  endDate: string;
  rate: string;
  status: "pending" | "validated" | "contract_generated";
  assignee: string;
  createdAt: string;
}

export interface Contract {
  id: string;
  contractId: string;
  vendor: string;
  client: string;
  status: ContractStatus;
  riskScore: number;
  riskLevel: RiskLevel;
  value: number;
  startDate: string;
  endDate: string;
  signatureStatus?: SignatureStatus;
  approvalStage: "legal" | "finance" | "compliance" | "complete";
  createdAt: string;
  jiraTicketId?: string;
}

export interface ApprovalStage {
  id: string;
  contractId: string;
  stage: "legal" | "finance" | "compliance";
  status: ApprovalStatus;
  approver: string;
  approverRole: string;
  comments?: string;
  timestamp?: string;
}

export interface ComplianceDoc {
  id: string;
  vendor: string;
  vendorId: string;
  type: ComplianceDocType;
  fileName: string;
  uploadedAt: string;
  expiryDate: string;
  status: "valid" | "expiring_soon" | "expired";
  daysUntilExpiry: number;
}

export interface RiskClause {
  id: string;
  clauseTitle: string;
  clauseText: string;
  riskLevel: RiskLevel;
  riskScore: number;
  suggestedRedline: string;
  category: string;
}

export interface AIRiskAnalysis {
  id: string;
  contractName: string;
  analyzedAt: string;
  overallRiskScore: number;
  overallRiskLevel: RiskLevel;
  clauses: RiskClause[];
  summary: string;
}

export interface DashboardMetrics {
  totalContracts: number;
  pendingApprovals: number;
  expiringCompliance: number;
  highRiskContracts: number;
  signedThisMonth: number;
  avgRiskScore: number;
}
